#include "types.h"
#include "user.h"
#include "pstat.h"

#define TICKET_A 30
#define TICKET_B 20
#define TICKET_C 10
#define ITERATIONS 10

void spin(int ticks) {
  int i;  
for (i = 0; i < ticks; ++i) {
    asm volatile("nop");  // Some dummy operation to simulate CPU usage
  }
}

int main() {
  int pid_A, pid_B, pid_C;

  if ((pid_A = fork()) == 0) {
    settickets(TICKET_A);
    while (1) {
      spin(100000);
    }
  }

  if ((pid_B = fork()) == 0) {
    settickets(TICKET_B);
    while (1) {
      spin(100000);
    }
  }

  if ((pid_C = fork()) == 0) {
    settickets(TICKET_C);
    while (1) {
      spin(100000);
    }
  }

  // Parent process
  int i;  
for (i = 0; i < ITERATIONS; ++i) {
    sleep(10);  // Sleep to allow a randomly chosen process to run
  }

  // Print the ticks of each process
  struct pstat st;
  getpinfo(&st);
  
for (i = 0; i < NPROC; ++i) {
    if (st.inuse[i] && (st.tickets[i] == TICKET_A || st.tickets[i] == TICKET_B || st.tickets[i] == TICKET_C) ) {
      printf(1, "Process %d: Ticks %d\n", st.pid[i], st.ticks[i]);
    }
  }

  // Wait for all children to finish  
for (i = 0; i < 3; ++i) {
    wait();
  }

  exit();
}



