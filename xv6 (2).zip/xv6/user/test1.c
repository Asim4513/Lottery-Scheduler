#include "types.h"
#include "user.h"

void busyWait(int iterations) {
    int i;
    for (i = 0; i < iterations; ++i) {
            // Some computation
	    asm volatile("nop");
	    }
}
	    
int main(int argc, char *argv[]) {
//Adjust the number of iterations based on the desired CPU time
int iterations = 1000000;
// Number of tickets (default to 1)
int tickets = 1;
if (argc > 1) {
	tickets = atoi(argv[1]);
}
iterations *= tickets;
// Run some computation in a loop
busyWait(iterations);
// Print a message to indicate completion
printf(1, "Test Lottery Program Completed\n");
wait();
exit();
return 0;
}                                         
