#ifndef PSTAT_H
#define PSTAT_H

#include "param.h"

struct pstat {
  int inuse[NPROC];       // whether this slot of the process table is in use (1 or 0)
  int tickets[NPROC];     // number of tickets this process has
  int pid[NPROC];         // process ID
  int ticks[NPROC];       // number of ticks each process has accumulated
  };

#endif // PSTAT_H

